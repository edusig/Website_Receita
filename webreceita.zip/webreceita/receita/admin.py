import models
from django.contrib import admin

admin.site.register(models.Autor)
admin.site.register(models.Categoria)
admin.site.register(models.Receita)
admin.site.register(models.ReceitaImagem)
admin.site.register(models.Ingredientes)